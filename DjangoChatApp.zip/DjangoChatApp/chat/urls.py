from django.contrib import admin
from django.urls import path
from chat import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.chat_view, name='chat'),
    path('add_numbers/', views.add_numbers, name='add_numbers'),
    path('upload_to_s3/', views.upload_to_s3, name='upload_to_s3'),
]
