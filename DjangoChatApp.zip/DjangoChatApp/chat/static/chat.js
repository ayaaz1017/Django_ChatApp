let chatSocket = null;

function startChat(username) {
    chatSocket = new WebSocket('ws://' + window.location.host + '/ws/chat/' + username + '/');
    chatSocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        const message = data['message'];
        document.querySelector('#messages').innerHTML += '<p>' + message + '</p>';
    };

    fetch('/api/get_messages/' + username + '/')
        .then(response => response.json())
        .then(data => {
            const messages = data.messages;
            let messageHTML = '';
            messages.forEach(msg => {
                messageHTML += '<p>' + msg.content + '</p>';
            });
            document.querySelector('#messages').innerHTML = messageHTML;
        });

    document.querySelector('#chatContainer').style.display = 'block';
    document.querySelector('#chatHeader').textContent = 'Chat with ' + username;
}

function sendMessage() {
    const message = document.querySelector('#messageInput').value;
    chatSocket.send(JSON.stringify({ 'message': message }));
}

function toggleMenu() {
    const menu = document.querySelector('#userList');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}
