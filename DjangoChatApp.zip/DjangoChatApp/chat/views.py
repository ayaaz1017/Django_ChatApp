import boto3
import json
from django.http import JsonResponse
from django.shortcuts import render
from .models import ChatMessage

# Render chat page
def chat_view(request):
    return render(request, 'chat.html')

# AWS Lambda: Add Numbers
def add_numbers(request):
    num1 = int(request.GET.get('num1'))
    num2 = int(request.GET.get('num2'))

    lambda_client = boto3.client('lambda', region_name='us-west-1')
    response = lambda_client.invoke(
        FunctionName='YourLambdaFunctionName',
        InvocationType='RequestResponse',
        Payload=json.dumps({'num1': num1, 'num2': num2}),
    )
    response_payload = json.loads(response['Payload'].read().decode())
    return JsonResponse(response_payload)

# AWS S3: File Upload
def upload_to_s3(request):
    uploaded_file = request.FILES['file']
    s3_client = boto3.client('s3')

    try:
        s3_client.upload_fileobj(uploaded_file, 'my-chat-app-bucket', uploaded_file.name)
        file_url = f'https://{AWS_S3_BUCKET_NAME}.s3.amazonaws.com/{uploaded_file.name}'
        return JsonResponse({'message': 'File uploaded successfully', 'file_url': file_url})
    except Exception as e:
        return JsonResponse({'message': str(e)}, status=400)
